# LAN ANH CLIENT PVP BETA (Fabric 1.21.4)

Mod client-side: Elytra Mace, Auto Crystal/Pearl, Safe Anchor, ESP + dây, ESP Block, Radar, Printer schematic.

## Build bằng GitHub (không cần cài gì)
1. Tạo repo GitHub, upload toàn bộ thư mục này.
2. Tab **Actions** -> workflow **Build** chạy tự động -> tải artifact `LanAnhClient-jar`.
3. Bỏ file `.jar` vào `.minecraft/mods` cùng **Fabric Loader 0.16+** và **Fabric API 0.119.2+1.21.4**.

## Phím mặc định (đổi trong Controls)
RShift = menu • R = Elytra Mace • G = Safe Anchor • P = Printer

## Schematic
Đặt file `.litematic` vào `.minecraft/schematics/`, vào menu -> *Xây theo Schematic* -> chọn file -> đứng vào gốc muốn xây -> bật Printer.

## Hình nền (Hello Kitty hoặc ảnh bất kỳ của bạn)
Đặt ảnh PNG 512x512 tại `src/main/resources/assets/safeanchor/textures/gui/bg.png`. Không có ảnh thì dùng nền hồng.

## Shader nhẹ
Menu -> Shader nhẹ: phủ màu, sáng/tối, viền tối, mẫu có sẵn, nút Ngẫu nhiên, nút Tối ưu FPS. Đây là overlay 2D (rất nhẹ), không phải shader GLSL.
