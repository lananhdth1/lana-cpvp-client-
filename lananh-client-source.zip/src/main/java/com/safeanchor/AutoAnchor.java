package com.safeanchor;

import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.state.property.Properties;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

/** Đặt anchor xong: tự đặt obsidian chắn (nếu có) -> nạp glowstone -> đổi sang ô totem -> nổ. */
public class AutoAnchor {
    static BlockPos anchor; static int phase, wait, fail;

    public static void toggle(MinecraftClient mc) {
        Config.I.anchor = !Config.I.anchor; Config.save();
        Util.msg("Safe Anchor: " + (Config.I.anchor ? "§aBẬT" : "§cTẮT"));
    }

    public static void onPlace(BlockHitResult hit) {
        if (!Config.I.anchor || !Config.I.enabled) return;
        var w = MinecraftClient.getInstance().world;
        BlockPos pos = w.getBlockState(hit.getBlockPos()).isReplaceable() ? hit.getBlockPos() : hit.getBlockPos().offset(hit.getSide());
        anchor = pos; phase = 0; wait = 2; fail = 0;
    }

    static void reset() { anchor = null; phase = 0; }

    public static void tick(MinecraftClient mc) {
        Config c = Config.I; var p = mc.player; var w = mc.world;
        if (anchor == null || !c.anchor || p == null || w == null) return;
        if (wait > 0) { wait--; return; }
        if (!w.getBlockState(anchor).isOf(Blocks.RESPAWN_ANCHOR)) { if (++fail > 20) reset(); return; }
        if (p.getEyePos().distanceTo(anchor.toCenterPos()) > c.reach + 1) { reset(); return; }

        switch (phase) {
            case 0 -> {
                if (c.anchorSafe && Util.has(s -> s.isOf(Items.OBSIDIAN))) {
                    double dx = p.getX() - (anchor.getX() + 0.5), dz = p.getZ() - (anchor.getZ() + 0.5);
                    Direction d = Direction.getFacing(dx, 0, dz);
                    BlockPos shield = anchor.offset(d);
                    if (w.getBlockState(shield).isReplaceable()) Util.placeBlock(shield, Items.OBSIDIAN);
                }
                phase = 1; wait = 1;
            }
            case 1 -> {
                int ch = w.getBlockState(anchor).get(Properties.CHARGES);
                if (ch < 1) {
                    if (!Util.selectItem(s -> s.isOf(Items.GLOWSTONE))) { Util.warn("Không có glowstone!"); reset(); return; }
                    Util.useOnBlock(anchor, Direction.UP);
                }
                phase = 2; wait = 1;
            }
            case 2 -> {
                if (w.getBlockState(anchor).get(Properties.CHARGES) < 1) { if (++fail > 10) reset(); wait = 1; return; }
                Util.select(c.totemSlot - 1);              // đổi sang ô totem rồi kích nổ
                Util.useOnBlock(anchor, Direction.UP);
                reset();
            }
            default -> reset();
        }
    }
}
