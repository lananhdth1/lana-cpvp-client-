package com.safeanchor;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.Items;
import net.minecraft.util.ActionResult;
import org.lwjgl.glfw.GLFW;

public class LanAnhClient implements ClientModInitializer {
    static KeyBinding menuKey, maceKey, anchorKey, printerKey;

    static KeyBinding reg(String id, int key) {
        return KeyBindingHelper.registerKeyBinding(new KeyBinding(id, InputUtil.Type.KEYSYM, key, "category.safeanchor"));
    }

    @Override public void onInitializeClient() {
        Config.load();
        menuKey = reg("key.safeanchor.menu", GLFW.GLFW_KEY_RIGHT_SHIFT);
        maceKey = reg("key.safeanchor.mace", GLFW.GLFW_KEY_R);
        anchorKey = reg("key.safeanchor.anchor", GLFW.GLFW_KEY_G);
        printerKey = reg("key.safeanchor.printer", GLFW.GLFW_KEY_P);

        UseBlockCallback.EVENT.register((pl, w, hand, hit) -> {
            if (w.isClient && pl.getStackInHand(hand).isOf(Items.RESPAWN_ANCHOR)) AutoAnchor.onPlace(hit);
            return ActionResult.PASS;
        });
        WorldRenderEvents.AFTER_TRANSLUCENT.register(Esp::render);
        HudRenderCallback.EVENT.register(Hud::render);
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
    }

    void tick(MinecraftClient mc) {
        while (menuKey.wasPressed()) mc.setScreen(Pages.main(null));
        while (maceKey.wasPressed()) ElytraMace.toggle(mc);
        while (anchorKey.wasPressed()) AutoAnchor.toggle(mc);
        while (printerKey.wasPressed()) Printer.toggle(mc);
        if (mc.player == null || mc.world == null) return;
        try {
            Util.autoTotem();
            ElytraMace.tick(mc);
            AutoCrystal.tick(mc);
            AutoAnchor.tick(mc);
            BlockEsp.tick(mc);
            Printer.tick(mc);
        } catch (Throwable t) { t.printStackTrace(); }
    }
}
