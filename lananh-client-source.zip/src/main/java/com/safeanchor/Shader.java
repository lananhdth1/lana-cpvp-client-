package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.ParticlesMode;

import java.util.Random;

/**
 * "Shader" nhẹ: phủ màu + chỉnh sáng/tối + viền tối (vignette) bằng vài ô fill -> gần như 0 FPS.
 * Không phải shader GLSL như Iris/Complementary (loại đó mới là thứ gây lag).
 */
public class Shader {
    public static final String[] PRESETS = {"Tùy chỉnh", "Hoàng hôn ấm", "Lạnh xanh", "Hồng Lan Anh", "Phim tối", "Sáng rõ"};

    static int argb(int pct, int rgb) { return (Math.max(0, Math.min(255, pct * 255 / 100)) << 24) | (rgb & 0xFFFFFF); }

    public static void render(DrawContext ctx, int W, int H) {
        Config c = Config.I;
        if (!c.shaderOn) return;
        if (c.shTintAlpha > 0) ctx.fill(0, 0, W, H, argb(c.shTintAlpha, c.shTint));
        if (c.shBright < 0) ctx.fill(0, 0, W, H, argb(-c.shBright, 0x000000));
        else if (c.shBright > 0) ctx.fill(0, 0, W, H, argb(c.shBright / 2, 0xFFFFFF));
        if (c.shVignette > 0) {
            int steps = 10;
            for (int i = 0; i < steps; i++) {
                int a = c.shVignette * (steps - i) / steps;
                int col = argb(a, c.shVignetteColor);
                int tx = (int) (W * 0.04), ty = (int) (H * 0.04);
                int x0 = tx * i / 1, y0 = ty * i / 1;
                // 4 dải mỏng: trên, dưới, trái, phải
                ctx.fill(x0, y0, W - x0, y0 + ty, col);
                ctx.fill(x0, H - y0 - ty, W - x0, H - y0, col);
                ctx.fill(x0, y0 + ty, x0 + tx, H - y0 - ty, col);
                ctx.fill(W - x0 - tx, y0 + ty, W - x0, H - y0 - ty, col);
            }
        }
    }

    public static void applyPreset(int p) {
        Config c = Config.I; c.shPreset = p; c.shaderOn = p != 0 || c.shaderOn;
        switch (p) {
            case 1 -> { c.shTint = 0xFF8C3C; c.shTintAlpha = 14; c.shBright = 0; c.shVignette = 25; c.shVignetteColor = 0x301000; }
            case 2 -> { c.shTint = 0x3C8CFF; c.shTintAlpha = 14; c.shBright = 0; c.shVignette = 20; c.shVignetteColor = 0x001030; }
            case 3 -> { c.shTint = 0xFF69B4; c.shTintAlpha = 16; c.shBright = 5; c.shVignette = 25; c.shVignetteColor = 0x400020; }
            case 4 -> { c.shTint = 0x000000; c.shTintAlpha = 0; c.shBright = -15; c.shVignette = 55; c.shVignetteColor = 0x000000; }
            case 5 -> { c.shTint = 0xFFFFFF; c.shTintAlpha = 0; c.shBright = 20; c.shVignette = 0; }
            default -> {}
        }
        Config.save();
    }

    public static void randomize() {
        Config c = Config.I; Random r = new Random();
        c.shaderOn = true; c.shPreset = 0;
        c.shTint = r.nextInt(0x1000000); c.shTintAlpha = 8 + r.nextInt(18);
        c.shBright = r.nextInt(41) - 20;
        c.shVignette = r.nextInt(50); c.shVignetteColor = r.nextInt(0x1000000) & 0x303030;
        Config.save();
    }

    /** Tối ưu FPS: giảm hạt, tắt mây, tắt bóng thực thể, đồ họa nhanh. Bấm nút để áp dụng. */
    public static void boostFps() {
        var o = MinecraftClient.getInstance().options;
        o.getParticles().setValue(ParticlesMode.MINIMAL);
        o.getCloudRenderMode().setValue(CloudRenderMode.OFF);
        o.getEntityShadows().setValue(false);
        o.getBiomeBlendRadius().setValue(1);
        o.getGraphicsMode().setValue(GraphicsMode.FAST);
        o.getEntityDistanceScaling().setValue(0.75);
        o.write();
        Util.msg("Đã bật tối ưu FPS");
    }
    public static void setViewDistance(int chunks) {
        var o = MinecraftClient.getInstance().options;
        o.getViewDistance().setValue(chunks);
        o.getSimulationDistance().setValue(Math.min(chunks, 8));
        o.write();
    }
}
